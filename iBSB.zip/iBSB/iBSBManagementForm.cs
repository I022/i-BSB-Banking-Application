﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace iBSB
{
    public partial class iBSBManagementForm : Form
    {
        CustomerRegistration customerRegistration = new CustomerRegistration();
        public iBSBManagementForm()
        {
            InitializeComponent();
        }

        private void btnRead_Click(object sender, EventArgs e)
        {
            //Reading from textfile the clients information
            string PathShow = @"C:\Users\Iman\Desktop\Documents\UCT\COURSES\MODULES\Commercial Programming\Project\INF_1003F_Project_SNDIMA002\iBSB\Clients.txt";
            var str = File.ReadAllText(PathShow);
            txtRead.Text = str;

            //number of clients 
            var lineCount = File.ReadLines(@"C:\Users\Iman\Desktop\Documents\UCT\COURSES\MODULES\Commercial Programming\Project\INF_1003F_Project_SNDIMA002\iBSB\Clients.txt").Count();     //collections property:count()
            textBox1.Text = "Today we opened " + Convert.ToString(lineCount - 3) + " accounts with a total of R " + customerRegistration.DepTotall ;
        }

        private void aboutToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Hide();
            About about = new About();
            about.Show();
        }

        private void summaryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string PathShow = @"C:\Users\Iman\Desktop\Documents\UCT\COURSES\MODULES\Commercial Programming\Project\INF_1003F_Project_SNDIMA002\iBSB\Clients.txt";
            var str = File.ReadAllText(PathShow);
            txtRead.Text = str;
        }

        private void printToolStripMenuItem_Click(object sender, EventArgs e)
        {
            printPreviewDialogReport.Document = printDocumentReport;
            printPreviewDialogReport.ShowDialog();
        }

        private void homeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Home home = new Home();
            home.Show();
        }

        private void printPreviewDialogReport_Load(object sender, EventArgs e)
        {

        }

        private void printDocumentReport_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            DateTime thisDay = DateTime.Today;
            string heading = "Summary for the day : " + thisDay.ToString("d") + " " + Environment.NewLine + "-------------------------------------------";
            string text = txtRead.Text + Environment.NewLine + textBox1.Text ;
            Font printFont = new System.Drawing.Font
            ("Arial", 11, System.Drawing.FontStyle.Regular);
            Font printFontH = new System.Drawing.Font
           ("Arial", 25, System.Drawing.FontStyle.Bold);
            

            // Draw the string 
            e.Graphics.DrawString(heading, printFontH,
           Brushes.SteelBlue, 10, 10);
            e.Graphics.DrawString(text, printFont,
            Brushes.Black, 10, 130);
        }

        private void iBSBManagementForm_Load(object sender, EventArgs e)
        {
            DateTime thisDay = DateTime.Today;
            label2dATE.Text = thisDay.ToString("d");
            printDocumentReport.DefaultPageSettings.Landscape = true;


        }
    }
}
