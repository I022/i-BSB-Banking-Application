﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ProgressBar;

namespace iBSB
{

    public partial class CustomerTransactions : Form
    {
       
        public CustomerTransactions()
        {
            InitializeComponent();
        }
        public string acc = "";

        private void CustomerTransactions_Load(object sender, EventArgs e)
        {
            CustomerRegistration customerRegistration = new CustomerRegistration();
            txtBalance.Text = customerRegistration.txtDeposit.Text;

        }

        private void customerRegistrationToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Hide();
            CustomerRegistration customerRegistration = new CustomerRegistration();
            customerRegistration.Show();
        }

        private void aboutToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Hide();
            About about = new About();
            about.Show();
        }

        private void homeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Home home = new Home();
            home.Show();
        }

        private void btnCheck_Click(object sender, EventArgs e)
        {
            CustomerRegistration customerRegistration = new CustomerRegistration();
            bool found = false;
            for (int i = 0; i < customerRegistration.Count; i++)
            {
                if (customerRegistration.accountArray[i] == txtAccCheck.Text)
                {
                    found = true;
                    MessageBox.Show("Could not find: " + txtAccCheck.Text, "Error");

                    break; //stop searching after corresponding entry found
                }
            }
            if (!found)//catering for eventuality for not finding corresponding name in array
            {
                MessageBox.Show("Welcome");
                groupBox1.Enabled = true;
                btnDeposit.Enabled = true;
                btnWithdraw.Enabled = true;
                btnAccStatement.Enabled = true;
                txtNewAmt.Enabled = true;
                txtWithdraw.Enabled = true;
               
            }
           

     
        }

        private void btnDeposit_Click(object sender, EventArgs e)
        {
            DepositAmount();        //calling method
        }

        private void btnWithdraw_Click(object sender, EventArgs e)
        {
            Withdrawal();          //calling method
        }

        //method for deposit 

        public void DepositAmount()
        {
            int AmountAdd;
            int Balance = Convert.ToInt32(txtBalance.Text);

            AmountAdd = Convert.ToInt32(txtNewAmt.Text);
            Balance += AmountAdd;

            txtBalance.Text = Convert.ToString(Balance);
        }

        //method for Withdrawal
        public void Withdrawal()
        {
            int AmountWithdraw = Convert.ToInt32(txtWithdraw.Text);
            int Balance = Convert.ToInt32(txtBalance.Text);

            if (Balance > AmountWithdraw)
            {
                Balance -= AmountWithdraw;

                txtBalance.Text = Convert.ToString(Balance);
            }
            else
                MessageBox.Show("Insufficient Funds! Please make another deposit before wanting to withdraw ", "ERROR");
            txtNewAmt.Focus();
            txtWithdraw.Clear();
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        { // printing
            string heading = "ACCOUNT SUMMARY: iBSB Bank" +Environment.NewLine + "-------------------------------------------";
            string text = "Name: " +lblNameAcc.Text+Environment.NewLine+"Surname: "+lblSurnameAcc.Text + Environment.NewLine + "Account Type: "+lblTypeAcc.Text + Environment.NewLine + "Account Number: "+lblNumAcc.Text+ Environment.NewLine+"Balance: "+ txtBalance.Text ;
            Font printFont = new System.Drawing.Font
            ("Arial", 25, System.Drawing.FontStyle.Regular);
            Font printFontH = new System.Drawing.Font
           ("Arial", 32, System.Drawing.FontStyle.Bold);

            // Draw the string 
            e.Graphics.DrawString(heading, printFontH,
           Brushes.SteelBlue,10, 10);
            e.Graphics.DrawString(text, printFont,
            Brushes.Black, 10, 130);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void btnAccStatement_Click(object sender, EventArgs e)
        {
            printPreviewDialogStatement.Document = printDocumentStatement;
            printPreviewDialogStatement.ShowDialog();
        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }
       
    }
   
}
