﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace iBSB
{
    public partial class Home : Form
    {
        CustomerRegistration customerRegistration = new CustomerRegistration();
        public Home()
        {
            InitializeComponent();
        }

        private void aboutToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Hide();
            About about = new About();
            about.Show();
        }

        private void whoAreWeToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void homePageToolStripMenuItem_Click(object sender, EventArgs e)
        {
          
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
      

        }

        private void btnClient_Click(object sender, EventArgs e)
        {
            cbxReg.Visible = true;
            cbxTrans.Visible = true;
        }

        private void Home_Load(object sender, EventArgs e)
        {
            cbxReg.Visible = false;
            cbxTrans.Visible = false;
        }

        private void btnEmployee_Click(object sender, EventArgs e)
        {
            cbxReg.Visible = false;
            cbxTrans.Visible = false;

            this.Hide();
            iBSBManagementForm iBSBManagementForm = new iBSBManagementForm();
            iBSBManagementForm.Show();

        }

        private void cbxReg_CheckedChanged(object sender, EventArgs e)
        {
            if (cbxReg.Checked)
            { cbxTrans.Enabled = false;
                btnGo.Visible = true;
            }
            else if (cbxReg.Checked==false)
            { cbxTrans.Enabled = true;
                btnGo.Visible = false;
            }

        }

        private void cbxTrans_CheckedChanged(object sender, EventArgs e)
        {
            if (cbxTrans.Checked)
            { cbxReg.Enabled = false;
                btnGo.Visible = true;
            }
            else if (cbxTrans.Checked==false)
            { cbxReg.Enabled = true;
                btnGo.Visible = false;
            }
        }

        private void btnGo_Click(object sender, EventArgs e)
        {
            if (cbxReg.Checked)
            {   this.Hide();
                CustomerRegistration customerRegistration = new CustomerRegistration();
                customerRegistration.Show();
            }
            else if (cbxTrans.Checked)
            {
                this.Hide();
                CustomerTransactions CustomerTransactions = new CustomerTransactions();
                CustomerTransactions.Show();
            }
        }

        private void homeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Home home = new Home();
            home.Show();
        }
    }
}
