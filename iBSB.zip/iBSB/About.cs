﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace iBSB
{
    public partial class About : Form
    {
        public About()
        {
            InitializeComponent();
        }

     

        private void cmbAbout_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            
        }

        //**********
        private void homeToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Home home = new Home();
            home.Show();
        }

        private void overviewToolStripMenuItem_Click(object sender, EventArgs e)
        {
            txtAbout.Text = "I Bank - Student Bank was founded by UCT Alumni.iBSB is tailored to provide students with an affordable, streamlined banking experience. iBSB's immediate focus is building a relationship with students to understand their needs and goals better and empower them to take control of their money. iBSB needs to create a banking product that gives flexibility and control to its customers.";
        }

        private void whatWeDoToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            txtAbout.Text = "Clients may register on the application without needing to visit a branch. The client is able to perform booking tranactions, such as depositing, withdrawing and viewing account balance.";
        }

        private void contactToolStripMenuItem_Click(object sender, EventArgs e)
        {
            txtAbout.Hide();
            
        }

        private void About_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void txtAbout_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnView_Click(object sender, EventArgs e)
        {
            string a = cmbAbout.Text;

            if (cmbAbout.Text == "Overview")
            {

                txtAbout.Text = "I Bank - Student Bank was founded by UCT Alumni.iBSB is tailored to provide students with an affordable, streamlined banking experience. iBSB's immediate focus is building a relationship with students to understand their needs and goals better and empower them to take control of their money. iBSB needs to create a banking product that gives flexibility and control to its customers.";
            }

            else if (cmbAbout.Text == "What we do")
            {
           
                txtAbout.Text = "Clients may register on the application without needing to visit a branch. The client is able to perform booking tranactions, such as depositing, withdrawing and viewing account balance.";
            }


            else if (a == "Contact")
            {
                txtAbout.Hide();
                groupBox2.Show();
            }
        }
    }
    }

