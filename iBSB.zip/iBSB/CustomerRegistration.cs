﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ProgressBar;

namespace iBSB
{
    public partial class CustomerRegistration : Form
    {
      


        public CustomerRegistration()
        {
            InitializeComponent();
        

        }
       
       public string[] accountArray = new string[200];              //Array
       string NameR, Surname, TypeA;
         public int Deposit, AccNum;                                        //data types 
        public int Count = 0;   
       public int DepTotall= 1350000;
        private void treeView1_AfterSelect(object sender, TreeViewEventArgs e)
        {
            
        }

        private void CustomerRegistration_Load(object sender, EventArgs e)
        {
         
            cmbType.Text = "Current Account";
            if (txtName.Text!=" " && txtSurname.Text!=" " && txtDeposit.Text!=" ")
            {
                btnCreate.Enabled = true;
            }
        }

        private void aboutToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Hide();
            About about = new About();
            about.Show();
        }

        private void homeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Home home = new Home();
            home.Show();
        }

        private void homePageToolStripMenuItem_Click(object sender, EventArgs e)
        {
          
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void customerRegistrationToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            
        }

        private void customerTransactionsToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Hide();
            CustomerTransactions customerTransactions = new CustomerTransactions();
            customerTransactions.Show();
            
        }

        private void splitContainer1_Panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
           
      }

        private void CustomerRegistration_FormClosed(object sender, FormClosedEventArgs e)
        {
            txtName.Clear();
            txtSurname.Clear();
            cmbType.Text = "Current Account";
            txtDeposit.Text = "0";
            txtAccNum.Clear();
        }

        private void txtDeposit_Enter(object sender, EventArgs e)
        {
            
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            try
            {                                                           //exception handling 
                NameR = txtName.Text;
                Surname = txtSurname.Text;
                TypeA = cmbType.Text;
                Deposit = Convert.ToInt32(txtDeposit.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + "\n\n" +
                ex.GetType().ToString() + "\n" +
                ex.StackTrace, "Exception");
            }

            //********************************ACCOUNT NUMBER
            Random random = new Random();                                   //for loop
            for (int i = 0; i < 1; i++)
            {
                AccNum = random.Next();
                txtAccNum.Text = Convert.ToString(AccNum);

            }

            //***************************************** // store account number in the array

            string accountNumbers = txtAccNum.Text; // get the account numbers from the textbox
            string[] accountArray = accountNumbers.Split(','); // split the string by comma and create an array

           //__________________________________________________
            Validation validation = new Validation();
           

            if (validation.IsEmpty(txtName) || validation.IsEmpty(txtSurname) || validation.IsEmpty(txtDeposit) || validation.IsEmpty(txtDeposit))
            {
                MessageBox.Show("Please fill in all required fields");
                if (validation.IsNumeric(txtDeposit))
                {
                    MessageBox.Show("Deposit has to be a numeric value");
                }
            }

            else
            {
                DialogResult result = MessageBox.Show("Name: " + NameR + Environment.NewLine + "Surname: " + Surname + Environment.NewLine + "Account Type: " + TypeA + Environment.NewLine + "Initial Deposit: " + String.Format("{0:C}", Deposit) + Environment.NewLine + "Account Number: " + txtAccNum.Text, "Account Summary", MessageBoxButtons.YesNo);

            if (result == DialogResult.Yes)

            {
                int CountCust = 0;
                MessageBox.Show("Your Account has been created. Thank you for choosing iBSB", "Confirmation");
                   //=========ManagementTab and Transfer 
                    CountCust++;
                    string CustomerInformation = Convert.ToString(CountCust+2) + "\t" + NameR + "\t"  + "\t" + "\t" + Surname + "\t"  + "\t" +"\t"+ txtAccNum.Text  + "\t" + "\t" + TypeA + "\t"  + "\t" + Convert.ToString(Deposit) + Environment.NewLine;
               



                    // display Transactions Page 

                    CustomerTransactions customerTransactions = new CustomerTransactions();
                customerTransactions.Show();
                    this.Hide();

                    customerTransactions.txtBalance.Text = txtDeposit.Text;
                customerTransactions.txtAccCheck.Text = txtAccNum.Text;
                customerTransactions.lblNameAcc.Text = txtName.Text;
                customerTransactions.lblSurnameAcc.Text = txtSurname.Text;
                customerTransactions.lblTypeAcc.Text = cmbType.Text;
                customerTransactions.lblNumAcc.Text = txtAccNum.Text;



                // to textfile 
              
                string fullPath = @"C:\Users\Iman\Desktop\Documents\UCT\COURSES\MODULES\Commercial Programming\Project\INF_1003F_Project_SNDIMA002\iBSB\Clients.txt";
                File.AppendAllText(fullPath, CustomerInformation);


                DepTotall = DepTotall+ Deposit;
                

              

                }

            else
            {
                this.Activate();
            }
        }


        }

        private void button1_Click(object sender, EventArgs e)
        {
          
        }
    }
}
