﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace iBSB
{
    public class Validation         //classes
    {
        public bool IsEmpty(TextBox textbox)
        {
            if (string.IsNullOrEmpty(textbox.Text))
            {
               
                return true;
            }
            return false;
        }
       public  bool IsNumeric(TextBox textbox)
        {
            int n;
            if (!int.TryParse(textbox.Text, out n))
            {
                
                return false;
            }
            return true;
        }

           }
}
