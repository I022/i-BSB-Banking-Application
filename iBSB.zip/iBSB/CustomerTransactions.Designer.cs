﻿namespace iBSB
{
    partial class CustomerTransactions
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CustomerTransactions));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.homeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.customerRegistrationToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtBalance = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnDeposit = new System.Windows.Forms.Button();
            this.btnWithdraw = new System.Windows.Forms.Button();
            this.btnAccStatement = new System.Windows.Forms.Button();
            this.btnCheck = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.txtAccCheck = new System.Windows.Forms.TextBox();
            this.txtNewAmt = new System.Windows.Forms.TextBox();
            this.txtWithdraw = new System.Windows.Forms.TextBox();
            this.printDocumentStatement = new System.Drawing.Printing.PrintDocument();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lblNumAcc = new System.Windows.Forms.Label();
            this.lblTypeAcc = new System.Windows.Forms.Label();
            this.lblSurnameAcc = new System.Windows.Forms.Label();
            this.lblNameAcc = new System.Windows.Forms.Label();
            this.lblNumberT = new System.Windows.Forms.Label();
            this.lblAccountT = new System.Windows.Forms.Label();
            this.lblSurnameT = new System.Windows.Forms.Label();
            this.lblNameT = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.printPreviewDialogStatement = new System.Windows.Forms.PrintPreviewDialog();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.homeToolStripMenuItem,
            this.aboutToolStripMenuItem1,
            this.customerRegistrationToolStripMenuItem1});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(11, 4, 0, 4);
            this.menuStrip1.Size = new System.Drawing.Size(1009, 27);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // homeToolStripMenuItem
            // 
            this.homeToolStripMenuItem.ForeColor = System.Drawing.Color.Black;
            this.homeToolStripMenuItem.Name = "homeToolStripMenuItem";
            this.homeToolStripMenuItem.Size = new System.Drawing.Size(52, 19);
            this.homeToolStripMenuItem.Text = "Home";
            this.homeToolStripMenuItem.Click += new System.EventHandler(this.homeToolStripMenuItem_Click);
            // 
            // aboutToolStripMenuItem1
            // 
            this.aboutToolStripMenuItem1.ForeColor = System.Drawing.Color.Black;
            this.aboutToolStripMenuItem1.Name = "aboutToolStripMenuItem1";
            this.aboutToolStripMenuItem1.Size = new System.Drawing.Size(52, 19);
            this.aboutToolStripMenuItem1.Text = "About";
            this.aboutToolStripMenuItem1.Click += new System.EventHandler(this.aboutToolStripMenuItem1_Click);
            // 
            // customerRegistrationToolStripMenuItem1
            // 
            this.customerRegistrationToolStripMenuItem1.Name = "customerRegistrationToolStripMenuItem1";
            this.customerRegistrationToolStripMenuItem1.Size = new System.Drawing.Size(137, 19);
            this.customerRegistrationToolStripMenuItem1.Text = "Customer Registration";
            this.customerRegistrationToolStripMenuItem1.Click += new System.EventHandler(this.customerRegistrationToolStripMenuItem1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(370, 191);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(263, 22);
            this.label1.TabIndex = 42;
            this.label1.Text = "ACCOUNT TRANSACTIONS";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(405, 45);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(167, 129);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 28;
            this.pictureBox1.TabStop = false;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtBalance);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Enabled = false;
            this.groupBox1.Location = new System.Drawing.Point(561, 324);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(264, 134);
            this.groupBox1.TabIndex = 43;
            this.groupBox1.TabStop = false;
            // 
            // txtBalance
            // 
            this.txtBalance.Enabled = false;
            this.txtBalance.Location = new System.Drawing.Point(88, 73);
            this.txtBalance.Name = "txtBalance";
            this.txtBalance.ReadOnly = true;
            this.txtBalance.Size = new System.Drawing.Size(100, 29);
            this.txtBalance.TabIndex = 43;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Enabled = false;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(86, 31);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(102, 22);
            this.label2.TabIndex = 42;
            this.label2.Text = "BALANCE";
            // 
            // btnDeposit
            // 
            this.btnDeposit.Enabled = false;
            this.btnDeposit.Location = new System.Drawing.Point(212, 509);
            this.btnDeposit.Name = "btnDeposit";
            this.btnDeposit.Size = new System.Drawing.Size(177, 39);
            this.btnDeposit.TabIndex = 44;
            this.btnDeposit.Text = "Deposit";
            this.btnDeposit.UseVisualStyleBackColor = true;
            this.btnDeposit.Click += new System.EventHandler(this.btnDeposit_Click);
            // 
            // btnWithdraw
            // 
            this.btnWithdraw.Enabled = false;
            this.btnWithdraw.Location = new System.Drawing.Point(432, 509);
            this.btnWithdraw.Name = "btnWithdraw";
            this.btnWithdraw.Size = new System.Drawing.Size(177, 39);
            this.btnWithdraw.TabIndex = 44;
            this.btnWithdraw.Text = "Withdraw";
            this.btnWithdraw.UseVisualStyleBackColor = true;
            this.btnWithdraw.Click += new System.EventHandler(this.btnWithdraw_Click);
            // 
            // btnAccStatement
            // 
            this.btnAccStatement.Enabled = false;
            this.btnAccStatement.Location = new System.Drawing.Point(661, 530);
            this.btnAccStatement.Name = "btnAccStatement";
            this.btnAccStatement.Size = new System.Drawing.Size(177, 39);
            this.btnAccStatement.TabIndex = 44;
            this.btnAccStatement.Text = "Account Statement";
            this.btnAccStatement.UseVisualStyleBackColor = true;
            this.btnAccStatement.Click += new System.EventHandler(this.btnAccStatement_Click);
            // 
            // btnCheck
            // 
            this.btnCheck.Location = new System.Drawing.Point(762, 262);
            this.btnCheck.Name = "btnCheck";
            this.btnCheck.Size = new System.Drawing.Size(85, 32);
            this.btnCheck.TabIndex = 45;
            this.btnCheck.Text = "ENTER";
            this.btnCheck.UseVisualStyleBackColor = true;
            this.btnCheck.Click += new System.EventHandler(this.btnCheck_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(244, 266);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(251, 24);
            this.label3.TabIndex = 47;
            this.label3.Text = "Enter Valid Account Number";
            // 
            // txtAccCheck
            // 
            this.txtAccCheck.Location = new System.Drawing.Point(501, 263);
            this.txtAccCheck.Name = "txtAccCheck";
            this.txtAccCheck.Size = new System.Drawing.Size(224, 29);
            this.txtAccCheck.TabIndex = 48;
            // 
            // txtNewAmt
            // 
            this.txtNewAmt.Enabled = false;
            this.txtNewAmt.Location = new System.Drawing.Point(212, 568);
            this.txtNewAmt.Name = "txtNewAmt";
            this.txtNewAmt.Size = new System.Drawing.Size(177, 29);
            this.txtNewAmt.TabIndex = 49;
            this.txtNewAmt.Text = "100000";
            // 
            // txtWithdraw
            // 
            this.txtWithdraw.Enabled = false;
            this.txtWithdraw.Location = new System.Drawing.Point(432, 568);
            this.txtWithdraw.Name = "txtWithdraw";
            this.txtWithdraw.Size = new System.Drawing.Size(177, 29);
            this.txtWithdraw.TabIndex = 49;
            this.txtWithdraw.Text = "10000";
            // 
            // printDocumentStatement
            // 
            this.printDocumentStatement.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.lblNumAcc);
            this.groupBox2.Controls.Add(this.lblTypeAcc);
            this.groupBox2.Controls.Add(this.lblSurnameAcc);
            this.groupBox2.Controls.Add(this.lblNameAcc);
            this.groupBox2.Controls.Add(this.lblNumberT);
            this.groupBox2.Controls.Add(this.lblAccountT);
            this.groupBox2.Controls.Add(this.lblSurnameT);
            this.groupBox2.Controls.Add(this.lblNameT);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Enabled = false;
            this.groupBox2.Location = new System.Drawing.Point(231, 324);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(264, 134);
            this.groupBox2.TabIndex = 43;
            this.groupBox2.TabStop = false;
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // lblNumAcc
            // 
            this.lblNumAcc.AutoSize = true;
            this.lblNumAcc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumAcc.ForeColor = System.Drawing.Color.DimGray;
            this.lblNumAcc.Location = new System.Drawing.Point(121, 106);
            this.lblNumAcc.Name = "lblNumAcc";
            this.lblNumAcc.Size = new System.Drawing.Size(19, 16);
            this.lblNumAcc.TabIndex = 47;
            this.lblNumAcc.Text = "---";
            // 
            // lblTypeAcc
            // 
            this.lblTypeAcc.AutoSize = true;
            this.lblTypeAcc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTypeAcc.ForeColor = System.Drawing.Color.DimGray;
            this.lblTypeAcc.Location = new System.Drawing.Point(102, 90);
            this.lblTypeAcc.Name = "lblTypeAcc";
            this.lblTypeAcc.Size = new System.Drawing.Size(15, 16);
            this.lblTypeAcc.TabIndex = 46;
            this.lblTypeAcc.Text = "--";
            // 
            // lblSurnameAcc
            // 
            this.lblSurnameAcc.AutoSize = true;
            this.lblSurnameAcc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSurnameAcc.ForeColor = System.Drawing.Color.DimGray;
            this.lblSurnameAcc.Location = new System.Drawing.Point(73, 74);
            this.lblSurnameAcc.Name = "lblSurnameAcc";
            this.lblSurnameAcc.Size = new System.Drawing.Size(15, 16);
            this.lblSurnameAcc.TabIndex = 45;
            this.lblSurnameAcc.Text = "--";
            // 
            // lblNameAcc
            // 
            this.lblNameAcc.AutoSize = true;
            this.lblNameAcc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNameAcc.ForeColor = System.Drawing.Color.DimGray;
            this.lblNameAcc.Location = new System.Drawing.Point(59, 58);
            this.lblNameAcc.Name = "lblNameAcc";
            this.lblNameAcc.Size = new System.Drawing.Size(15, 16);
            this.lblNameAcc.TabIndex = 44;
            this.lblNameAcc.Text = "--";
            // 
            // lblNumberT
            // 
            this.lblNumberT.AutoSize = true;
            this.lblNumberT.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumberT.Location = new System.Drawing.Point(6, 106);
            this.lblNumberT.Name = "lblNumberT";
            this.lblNumberT.Size = new System.Drawing.Size(109, 16);
            this.lblNumberT.TabIndex = 43;
            this.lblNumberT.Text = "Account Number:";
            this.lblNumberT.Click += new System.EventHandler(this.label7_Click);
            // 
            // lblAccountT
            // 
            this.lblAccountT.AutoSize = true;
            this.lblAccountT.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAccountT.Location = new System.Drawing.Point(6, 90);
            this.lblAccountT.Name = "lblAccountT";
            this.lblAccountT.Size = new System.Drawing.Size(90, 16);
            this.lblAccountT.TabIndex = 43;
            this.lblAccountT.Text = "Account Type";
            this.lblAccountT.Click += new System.EventHandler(this.label7_Click);
            // 
            // lblSurnameT
            // 
            this.lblSurnameT.AutoSize = true;
            this.lblSurnameT.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSurnameT.Location = new System.Drawing.Point(6, 74);
            this.lblSurnameT.Name = "lblSurnameT";
            this.lblSurnameT.Size = new System.Drawing.Size(61, 16);
            this.lblSurnameT.TabIndex = 43;
            this.lblSurnameT.Text = "Surname";
            // 
            // lblNameT
            // 
            this.lblNameT.AutoSize = true;
            this.lblNameT.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNameT.Location = new System.Drawing.Point(6, 58);
            this.lblNameT.Name = "lblNameT";
            this.lblNameT.Size = new System.Drawing.Size(47, 16);
            this.lblNameT.TabIndex = 43;
            this.lblNameT.Text = "Name:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Enabled = false;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(42, 25);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(193, 22);
            this.label4.TabIndex = 42;
            this.label4.Text = "ACCOUNT HOLDER";
            // 
            // printPreviewDialogStatement
            // 
            this.printPreviewDialogStatement.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialogStatement.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialogStatement.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialogStatement.Enabled = true;
            this.printPreviewDialogStatement.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialogStatement.Icon")));
            this.printPreviewDialogStatement.Name = "printPreviewDialogStatement";
            this.printPreviewDialogStatement.Visible = false;
            // 
            // CustomerTransactions
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSteelBlue;
            this.ClientSize = new System.Drawing.Size(1009, 617);
            this.Controls.Add(this.txtWithdraw);
            this.Controls.Add(this.txtNewAmt);
            this.Controls.Add(this.txtAccCheck);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnCheck);
            this.Controls.Add(this.btnAccStatement);
            this.Controls.Add(this.btnWithdraw);
            this.Controls.Add(this.btnDeposit);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "CustomerTransactions";
            this.Text = "Customer Transactions";
            this.Load += new System.EventHandler(this.CustomerTransactions_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.MenuStrip menuStrip1;
        public System.Windows.Forms.ToolStripMenuItem homeToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem1;
        public System.Windows.Forms.ToolStripMenuItem customerRegistrationToolStripMenuItem1;
        public System.Windows.Forms.Label label1;
        public System.Windows.Forms.PictureBox pictureBox1;
        public System.Windows.Forms.GroupBox groupBox1;
        public System.Windows.Forms.TextBox txtBalance;
        public System.Windows.Forms.Label label2;
        public System.Windows.Forms.Button btnDeposit;
        public System.Windows.Forms.Button btnWithdraw;
        public System.Windows.Forms.Button btnAccStatement;
        public System.Windows.Forms.Button btnCheck;
        public System.Windows.Forms.Label label3;
        public System.Windows.Forms.TextBox txtAccCheck;
        public System.Windows.Forms.TextBox txtNewAmt;
        public System.Windows.Forms.TextBox txtWithdraw;
        public System.Drawing.Printing.PrintDocument printDocumentStatement;
        public System.Windows.Forms.GroupBox groupBox2;
        public System.Windows.Forms.Label label4;
        public System.Windows.Forms.Label lblAccountT;
        public System.Windows.Forms.Label lblSurnameT;
        public System.Windows.Forms.Label lblNameT;
        public System.Windows.Forms.Label lblNumberT;
        public System.Windows.Forms.PrintPreviewDialog printPreviewDialogStatement;
        public System.Windows.Forms.Label lblNumAcc;
        public System.Windows.Forms.Label lblTypeAcc;
        public System.Windows.Forms.Label lblSurnameAcc;
        public System.Windows.Forms.Label lblNameAcc;
    }
}